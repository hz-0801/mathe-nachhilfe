# Kasten-Sperre: ganze Gleichungen und Zahlenpaare aus Merkkasten/Original des Eintrags (2.1)
import re, sys
gesperrt_gl = ['x+y=7','2x-y=2','y=-x+7','y=2x-2','x+y=9','3x+2y=22','y=9-x','3x+2y=12','5x-4y=-2','6x+4y=24',
  'x+y=2,50','4x+3y=8,50','x+y=63','9x+3y=352,20','x+y=3,80','6x+5y=21,20','r+t=13','r+t=3,80','6r+5t=21,20',
  'x_2+2x_3=5','x_2+x_3=3','-4x+z=4','2y-z=4','4y-2z=8','-2x+y=t']
gesperrt_paar = ['(3|4)','(4|5)','(2|3)','(1|-1)','(5;1;2)','(-3;-2;-8)']
def norm(t):
    t = t.replace('{,}', ',').replace('\\mid', '|').replace('\\cdot', '').replace('\\,', '').replace(' ', '').replace('$', '')
    return t
fehl = 0
for f in sys.argv[1:]:
    for i, z in enumerate(open(f, encoding='utf-8'), 1):
        n = norm(z)
        for g in gesperrt_gl:
            for m in re.finditer(re.escape(g), n):
                a, b = m.start(), m.end()
                vor = n[a-1] if a > 0 else ''; nach = n[b] if b < len(n) else ''
                if (vor == '' or not (vor.isalnum() or vor in ',.')) and (nach == '' or not (nach.isalnum() or nach in ',.')):
                    print(f"{f}:{i}: Kastengleichung {g}"); fehl += 1
        for p in gesperrt_paar:
            if p in n: print(f"{f}:{i}: Kastenpaar {p}"); fehl += 1
print(f"Kastentreffer: {fehl}")
