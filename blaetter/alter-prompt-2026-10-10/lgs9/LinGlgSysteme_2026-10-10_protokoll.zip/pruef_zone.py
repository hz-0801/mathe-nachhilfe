# Zone, Nr. 1–10 (Blattwerte aus zone_l.tex)
probe('1a', ['x+4=9'], {x: 5}, [True]); probe('1b', ['3*x=12'], {x: 4}, [True])
probe('1c', ['2*x-7=1'], {x: 3}, [False]); probe('1d', ['5-2*x=11'], {x: -3}, [True])
probe('1e', ['3*x+2=x+8'], {x: 3}, [True])
for t, s, b in [('2a','x+y=6','-x+6'),('2b','y-x=2','x+2'),('2c','2*x+y=5','-2*x+5'),('2d','2*y=6*x+4','3*x+2'),('2e','x-y=3','x-3'),('2f','4*x+2*y=8','-2*x+4')]:
    umstellen(t, s, 'y', b)
# 3: Punkte liegen auf den Geraden
probe('3a', ['y=x+1'], {x: 0, y: 1}, [True]); probe('3a2', ['y=x+1'], {x: 5, y: 6}, [True])
probe('3b', ['y=2*x-1'], {x: 0, y: -1}, [True]); probe('3b2', ['y=2*x-1'], {x: 3, y: 5}, [True])
probe('3c', ['y=-0.5*x+3'], {x: 0, y: 3}, [True]); probe('3c2', ['y=-0.5*x+3'], {x: 4, y: 1}, [True])
wahr('4a', 2 == 2, True, 'm gleich: '); wahr('4b', 3 == 1, False, 'm gleich: ')
wahr('4c', -1 == 1, False, 'm gleich: '); wahr('4d', 0.5 == 0.5, True, 'm gleich: ')
wert('5a', '12-15', -3); wert('5b', '2*4.5', 9); wert('5c', '4*1.2+2*0.85', 6.5)
wert('5d', '(-2)*(-3)', 6); wert('5e', '41.4/6', 6.9); wert('5f', '-4*2.5+3', -7)
for t, s, b in [('6a','2*(x+3)','2*x+6'),('6b','3*(4-x)','12-3*x'),('6c','4*x+3*(8-x)','x+24'),('6d','10-(x-4)','14-x'),('6e','2*x-3*(x-5)','-x+15'),('6f','3*x+2*y-x+4*y','2*x+6*y')]:
    term(t, s, b)
for t, s, b in [('7a','3*x=21',7),('7b','x-4=10',14),('7c','4*x+3=2*x+11',4),('7d','2*x+9=3',-3),('7e','0.5*x+2=3.5',3),('7f','5*x-2*(x-3)=21',5)]:
    gleichung(t, s, b)
gleichung('8', '4*x-2*(x-3)=14', 4)
wahr('8F', solve(gl('4*x-2*x-6=14'), x)[0] == 10, True, 'Vorlage ergibt 10 (falsch): ')
gleichung('9a', '6*x-3*(x-2)=21', 5); gleichung('9b', '5*x-2*(x+1)=10', 4)
gleichung('10a', '4*x=6', 1.5); gleichung('10b', 'x+x+3=25', 11)
gleichung('10c', '3*8.5+4*x=37.5', 3); gleichung('10d', '0.4*x+3=5', 5)
