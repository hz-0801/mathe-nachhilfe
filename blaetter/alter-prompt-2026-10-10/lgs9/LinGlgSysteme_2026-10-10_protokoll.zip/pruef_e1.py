P=lambda s:[gl(t) for t in s]
def lsg(nr,eqs,pt,blatt):
    sk=[simplify(e.lhs.subs(pt)-e.rhs.subs(pt))==0 for e in P(eqs)]
    s={(True,True):'beide',(True,False):'I',(False,True):'II',(False,False):'keine'}[tuple(sk)]
    zeile(nr,s,blatt,s==blatt)
lsg('11a',['x+y=5','y=x+3'],{x:1,y:4},'beide'); lsg('11b',['x+y=5','x-y=2'],{x:4,y:1},'I')
lsg('11c',['y=2*x+1','x+y=6'],{x:1,y:3},'I'); lsg('11d',['y=3*x+1','2*x+y=5'],{x:0,y:2},'keine')
lsg('11e',['2*x+y=2','y=-x+3'],{x:-1,y:4},'beide')
for t,s,b in [('12a','6-x',[6,5,4,3]),('12b','3*x',[0,3,6,9]),('12c','x-1',[-1,0,1,2]),('12d','10-2*x',[10,8,6,4])]:
    v=[S(s).subs(x,i) for i in range(4)]; zeile(t,v,b,v==b)
umstellen('13b','x+y=4','y','-x+4'); umstellen('13c','3*x-y=2','y','3*x-2')
probe('13c-P',['y=3*x-2'],{x:2,y:4},[True])
lsg_=lambda nr,e,b: lgs(nr,e,b)
lgs('14a',['y=x-1','y=-x+5'],{'x':3,'y':2}); lgs('14b',['x+y=6','y=2*x'],{'x':2,'y':4})
lgs('15c',['y=0.5*x+1','y=-x+4'],{'x':2,'y':2}); lgs('15d',['x-y=3','x+y=1'],{'x':2,'y':-1})
lgs('16a',['y=x-2','y=-x+6'],{'x':4,'y':2}); lgs('16b',['y=x-2','y=-2*x+7'],{'x':3,'y':1}); lgs('16c',['y=-x+6','y=-2*x+7'],{'x':1,'y':5})
lgs('17a',['y=0.5*x+1','y=0.5*x-2'],'keine'); lgs('17b',['y=0.5*x+1','y=-x+4'],{'x':2,'y':2}); lgs('17c',['y=-2*x+4','y=-2*x+4'],'unendlich')
def anz(nr,e,b):
    lg=[gl(s) for s in e]; sol=solve(lg,[x,y],dict=True)
    s='keine' if not sol else ('unendlich' if len(sol[0])<2 else 'eine'); zeile(nr,s,b,s==b)
anz('18a',['y=3*x+1','y=3*x-4'],'keine'); anz('18b',['y=2*x+1','y=-2*x+1'],'eine'); anz('18c',['y=0.5*x+3','y=3+0.5*x'],'unendlich')
anz('18d',['x+y=4','y=-x+1'],'keine'); anz('18e',['2*y=4*x+6','y=2*x+3'],'unendlich'); anz('18f',['y=2*(x+1)','y=2*x+1'],'keine'); anz('18g',['3*x+y=2','y=3*x+2'],'eine')
anz('19a',['y=2*x-1','y=2*x+3'],'keine'); probe('19a-P',['y=2*x+3'],{x:0,y:3},[True])
lgs('19b',['y=2*x-1','y=-x+8'],{'x':3,'y':5}); anz('19c',['y=2*x-1','2*y=4*x-2'],'unendlich')
lgs('20a',['x+y=10','y=x+4'],{'x':3,'y':7}); lgs('20b',['x+y=11','2*x+y=15'],{'x':4,'y':7}); lgs('20c',['x+y=12','3*x+5*y=44'],{'x':8,'y':4})
wahr('21a',0<=0+1,True,'(0|0) in y<=x+1: '); wahr('21b',0+0>=4,False,'(0|0) in x+y>=4: ')
wahr('22b1',all([0<=-0+6,0>=0,0>=0]),True,'(0|0) Ecke: '); lgs('22b2',['y=-x+6','y=x'],{'x':3,'y':3}); wahr('22b3',6<=-0+6 and 6>=0,True,'(0|6): ')
wahr('22c',(3<=-1+6) and (3>=1) and (1>=0),True,'P: '); wahr('22d',(2<=-3+6) and (2>=3) and (3>=0),False,'Q: ')
umstellen('23a','2*x+y=7','y','-2*x+7'); probe('23b',['y=x+1','y=-2*x+5'],{x:1,y:2},[True,False])
lgs('23b-genau',['y=x+1','y=-2*x+5'],{'x':Rational(4,3),'y':Rational(7,3)})
wahr('24a',3==3,True,'gleiche Steigung: ')
lgs('25',['x+y=14','2*x+4*y=44'],{'x':6,'y':8})
