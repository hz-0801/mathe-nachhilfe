# Prüfskript: rechnet jede Lösung unabhängig nach. Aufruf: python3 pruef.py <datei>
import sys
from sympy import symbols, Eq, solve, sympify, simplify, Rational, nsimplify, expand
x, y, z = symbols('x y z')
ABW = 0
def S(s): return sympify(s.replace('^', '**'), locals={'x': x, 'y': y, 'z': z})
def zeile(nr, skript, blatt, ok):
    global ABW
    if not ok: ABW += 1
    print(f"{nr:6} | Skript: {skript} | Blatt: {blatt} | {'OK' if ok else 'ABWEICHUNG'}")
def gl(s):
    l, r = s.split('=')
    return Eq(S(l), S(r))
def lgs(nr, eqs, blatt):
    """eqs: Liste 'lhs=rhs'; blatt: dict oder 'keine' / 'unendlich'"""
    e = [gl(s) for s in eqs]
    var = sorted(set().union(*[q.free_symbols for q in e]), key=str)
    sol = solve(e, var, dict=True)
    if not sol: sk = 'keine'
    elif any(len(s) < len(var) for s in sol): sk = 'unendlich'
    else: sk = {str(k): nsimplify(v) for k, v in sol[0].items()}
    if isinstance(blatt, dict):
        b = {k: nsimplify(v) for k, v in blatt.items()}
        ok = isinstance(sk, dict) and all(sk[k] == b[k] for k in sk) and set(sk) == set(b)
    else: ok = sk == blatt
    zeile(nr, sk, blatt, ok)
def gleichung(nr, s, blatt):
    sol = solve(gl(s), x)
    zeile(nr, sol, blatt, len(sol) == 1 and nsimplify(sol[0]) == nsimplify(blatt))
def term(nr, s, blatt):
    zeile(nr, expand(S(s)), blatt, simplify(S(s) - S(blatt)) == 0)
def wert(nr, s, blatt):
    v = nsimplify(S(s)); zeile(nr, v, blatt, v == nsimplify(blatt))
def probe(nr, eqs, punkt, blatt):
    """blatt: Liste der Wahrheitswerte je Gleichung"""
    sk = [bool(simplify(gl(s).lhs.subs(punkt) - gl(s).rhs.subs(punkt)) == 0) for s in eqs]
    zeile(nr, sk, blatt, sk == blatt)
def umstellen(nr, s, nach, blatt):
    v = {'x': x, 'y': y, 'z': z}[nach]
    sol = solve(gl(s), v)
    zeile(nr, sol[0], blatt, simplify(sol[0] - S(blatt)) == 0)
def wahr(nr, ausdruck, blatt, text=''):
    zeile(nr, f"{text}{ausdruck}", blatt, ausdruck == blatt)
exec(open(f"pruef_{sys.argv[1]}.py", encoding='utf-8').read())
print(f"Abweichungen: {ABW}")
