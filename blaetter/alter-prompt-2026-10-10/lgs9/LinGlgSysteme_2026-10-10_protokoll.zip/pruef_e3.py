def vz(nr,a,b,blatt):
    ea=S(a.split('=')[0]); eb=S(b.split('=')[0]); sk='keins'
    for v in (x,y):
        if ea.coeff(v)==eb.coeff(v): sk='gleiche Vorzahl'; break
        if ea.coeff(v)==-eb.coeff(v): sk='Gegenzahlen'; break
    zeile(nr,sk,blatt,sk==blatt)
vz('37a','3*x+2*y=7','5*x-2*y=1','Gegenzahlen'); vz('37b','4*x+y=9','4*x-3*y=1','gleiche Vorzahl'); vz('37c','2*x+5*y=4','3*x+4*y=6','keins')
vz('37d','-x+3*y=5','x+2*y=10','Gegenzahlen'); vz('37e','6*x-2*y=8','x-2*y=-7','gleiche Vorzahl')
lgs('38a',['x+y=9','x-y=1'],{'x':5,'y':4}); lgs('38b',['2*x+y=11','x-y=1'],{'x':4,'y':3}); lgs('38c',['x+3*y=13','-x+y=3'],{'x':1,'y':4}); lgs('38d',['4*x-2*y=10','x+2*y=10'],{'x':4,'y':3})
lgs('39e',['3*x+y=14','x+y=6'],{'x':4,'y':2}); lgs('39f',['2*x+5*y=16','2*x+y=8'],{'x':3,'y':2}); lgs('39g',['3*x+2*y=16','x-y=2'],{'x':4,'y':2}); lgs('39h',['5*x+3*y=21','2*x+y=8'],{'x':3,'y':2})
lgs('40i',['2*x+3*y=12','3*x+2*y=13'],{'x':3,'y':2}); lgs('40j',['4*x-3*y=7','5*x+2*y=26'],{'x':4,'y':3}); lgs('40k',['-3*x+2*y=-13','2*x-5*y=5'],{'x':5,'y':1}); lgs('40l',['0.5*x+y=4','1.5*x-2*y=2'],{'x':4,'y':2})
lgs('41a',['2*(x+y)=x+9','3*x=2*y+3'],{'x':3,'y':3}); lgs('41b',['x/2+y=5','x-3*(y-1)=-2'],{'x':4,'y':3})
lgs('42a',['2*x+y=5','4*x+2*y=7'],'keine'); lgs('42b',['x-3*y=2','-2*x+6*y=-4'],'unendlich')
wahr('43c',3+(-3)==0 and 4==4,True,'4y,-4y Gegenzahlen: ')
wert('44a','2*3+5*1',11); probe('44a-II',['4*x-5*y=7'],{x:3,y:1},[True]); probe('44b-I',['3*x+2*y=4'],{x:-2,y:5},[True])
z_=symbols('a'); v=solve(Eq(z_*(-2)+5,13),z_)[0]; zeile('44b',v,-4,v==-4)
anz2=lambda: None
lgs('44c',['x+2*y=3','2*x+4*y=6'],'unendlich')
lgs('45',['3*x+4*y=2','5*x-2*y=12'],{'x':2,'y':-1})
lgs('46a',['x+3*y=7','2*x-y=7'],{'x':4,'y':1}); gleichung('46a-Fehler','7*x=14',2); lgs('46b',['5*x+2*y=18','3*x+2*y=14'],{'x':2,'y':4})
