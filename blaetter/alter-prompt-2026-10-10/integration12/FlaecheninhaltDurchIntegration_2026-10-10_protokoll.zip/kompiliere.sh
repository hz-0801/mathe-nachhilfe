#!/bin/bash
# $1 = Einheitsdatei (z.B. e1_a), $2 = Kopfzeilen-Bezeichnung
cd /root/work/hefte/integration12
cat > rahmen_$1.tex <<EOT
\documentclass[11pt]{article}
\usepackage{mathblatt}
\begin{document}
\blattkopf{Flächeninhalt durch Integration}{$2}
\input{$1}
\end{document}
EOT
xelatex -interaction=nonstopmode rahmen_$1.tex >/dev/null 2>&1
echo "== $1"; grep -E "^!|mathblatt Warning|Overfull" rahmen_$1.log | head -8
rm -f $1-*.png; pdftoppm -r 60 -png rahmen_$1.pdf $1 >/dev/null; ls $1-*.png | tr '\n' ' '; echo
