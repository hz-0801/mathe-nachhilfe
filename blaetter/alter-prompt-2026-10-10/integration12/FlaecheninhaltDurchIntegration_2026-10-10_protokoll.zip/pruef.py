#!/usr/bin/env python3
"""pruef.py <einheit>: rechnet die Lösungen einer Einheit unabhängig nach.
Je Ergebnis: Nummer, Skriptwert, Blattwert, OK/ABWEICHUNG; letzte Zeile: Zahl der Abweichungen."""
import sys, math
from sympy import *
x = symbols('x')
E = exp(1)
def I(f, a, b): return integrate(f, (x, a, b))
def A(f, a, b): return Abs(I(f, a, b))
def nst(f): return sorted([r for r in solve(f, x) if r.is_real])

zeilen = []   # (nr, skript, blatt)
def z(nr, s, b): zeilen.append((nr, s, b))

einheit = sys.argv[1]
if einheit == 'zone':
    for nr, f, F in [('1a', 3*x**2, x**3), ('1b', 2*x, x**2), ('1c', x**3-4*x+1, x**4/4-2*x**2+x),
                     ('1d', exp(2*x), exp(2*x)/2), ('1e', 1/x**2, -1/x), ('1f', (2*x-1)**3, (2*x-1)**4/8)]:
        z(nr, simplify(diff(F, x)-f), 0)
    z('2a', I(2*x,0,2), 4); z('2b', I(3*x**2,1,3), 26); z('2c', I(x**2+1,-2,1), 6)
    z('2d', I(exp(x),0,1), E-1); z('2e', I(exp(x/2),0,2), 2*E-2); z('2f', I(1/x**2,1,4), Rational(3,4))
    z('3', I(2*x+exp(x),0,3), 8+E**3)
    z('4a', I(3*x**2+exp(x),0,2), 7+E**2); z('4b', I(exp(x)-1,-1,1), E-1/E-2)
    z('5a', nst(x**2-9), [-3,3]); z('5b', nst(x**2-4*x), [0,4]); z('5c', nst(x**2+x-6), [-3,2])
    z('5d', nst(x**3-4*x), [-2,0,2]); z('5e', nst(x**2/2-2), [-2,2]); z('5f', nst(exp(x)*(x-1)), [1])
    z('5g', nst(x**3-3*x**2-4*x+12), [-2,2,3])
    z('6a', nst(x**2-4), [-2,2]); z('6b', nst(x**2-x), [0,1]); z('6c', nst(x**2-2*x-(x-2)), [1,2])
    z('6d', nst(-x**2+4-(x+2)), [-2,1]); z('6e', nst(x**3-4*x), [-2,0,2]); z('6f', nst(exp(x)-exp(2*x)), [0])
    z('7a', 6*4/2, 12); z('7b', (8+4)/2*3, 18); z('7c', pi*4/2, 2*pi); z('7d', 4*6/2, 12)
    z('7e', (3+5)/2*4, 16)
    z('8a', 3*2, 6); z('8b', 3*4, 12); z('8c', 4.5*100, 450); z('8d', 2.4*1000, 2400); z('8e', 500000*2.4/1000, 1200); z('8f', 3.2*25, 80)
    sym = lambda f: 'A' if simplify(f.subs(x,-x)-f)==0 else ('P' if simplify(f.subs(x,-x)+f)==0 else 'K')
    for nr, f, b in [('9a',x**2,'A'),('9b',x**3,'P'),('9c',x**3-x,'P'),('9d',x**3+1,'K'),('9e',x**4-2*x**2,'A'),('9f',x**2+x,'K'),('9g',2*x**5-5*x,'P'),('9h',1/x,'P')]:
        z(nr, sym(f), b)
elif einheit == 'e1':
    z('11a', A(4-x**2,-2,2), Rational(32,3)); z('11b', A(x**2-2*x,0,2), Rational(4,3))
    z('11c', A(-x**2+6*x-5,1,5), Rational(32,3)); z('11d', A(x**2+2*x-3,-3,1), Rational(32,3))
    z('11e-nst', nst(x**3-2*x**2-5*x+6), [-2,1,3]); z('11e', A(x**3-2*x**2-5*x+6,1,3), Rational(16,3))
    z('11f', A(x**2-4*x+3,0,1), Rational(4,3)); z('11g', I(exp(x/2),0,2), 2*E-2)
    z('11h-F', simplify(diff((x-1)*exp(x),x)-x*exp(x)), 0); z('11h', I(x*exp(x),1,2), E**2)
    z('12a', A(x**3-4*x,-2,0)+A(x**3-4*x,0,2), 8); z('12b', A(x**3-3*x**2+2*x,0,1)+A(x**3-3*x**2+2*x,1,2), Rational(1,2))
    z('12c', A(x**2-1,0,1)+A(x**2-1,1,2), 2); z('12d', A(3*x**2-6*x,0,2), 4)
    z('12e', I(-x**2/4+4,-4,4)-5, Rational(49,3)); z('12f', A(2*exp(x)-4,0,log(2)), 4*log(2)-2)
    z('13a', A(x**3-x,-1,0)+A(x**3-x,0,1), Rational(1,2)); z('13b', A(x**2-4*x,0,4), Rational(32,3))
    z('15c', I(-x**2/2+2*x,0,4), Rational(16,3))
elif einheit == 'e2':
    z('17a', I(4-x**2,0,1), Rational(11,3)); z('17b', I(x+1-x**2,0,1), Rational(7,6))
    z('17c', I(-x**2+3-(x**2+1),-1,1), Rational(8,3)); z('17d', I(exp(x)-x,0,1), E-Rational(3,2))
    z('17e', nst(x**2-2*x), [0,2]); z('17e-A', A(x**2-2*x,0,2), Rational(4,3))
    z('17f', nst(-x**2+4-(x+2)), [-2,1]); z('17f-A', A(-x**2+4-(x+2),-2,1), Rational(9,2))
    z('17g', nst(x**3-x), [-1,0,1]); z('17g-A', A(x**3-x,-1,0)+A(x**3-x,0,1), Rational(1,2))
    z('17h', nst(x**2-2*x+3-6), [-1,3]); z('17h-A', A(x**2-2*x+3-6,-1,3), Rational(32,3))
    z('17i', A(4-(-x**2+4*x),0,4), Rational(16,3))
    z('17j-F', simplify(diff((x-1)*exp(x),x)-x*exp(x)), 0); z('17j', A(E*x-x*exp(x),0,1), E/2-1)
    z('18a-nst', nst(2*x+1), [-Rational(1,2)]); z('18a-schnitt', nst(4-x**2-(2*x+1)), [-3,1])
    z('18a', I(4-x**2,-Rational(1,2),2)-I(2*x+1,-Rational(1,2),1), Rational(121,24))
    z('18b-t1', [diff(x**2,x).subs(x,-1), (x**2).subs(x,-1)-diff(x**2,x).subs(x,-1)*(-1)], [-2,-1])
    z('18b', 2*A(x**2-(2*x-1),0,1), Rational(2,3))
    u=symbols('u'); z('18c', simplify(I(2*x-x**2,0,u)-(u**2-u**3/3)), 0)
    z('19a', A(x+2-x**2,-1,2), Rational(9,2)); z('19a-paul', I(x**2-x-2,-1,2), -Rational(9,2))
    z('19b', A(-x**2+4-(x**2+2),-1,1), Rational(8,3)); z('19b-sina', I(-x**2+4,-1,1), Rational(22,3))
    z('21a', nst(-x**2/4+4-(x**2/4+2)), [-2,2]); z('21b', A(2-x**2/2,-2,2), Rational(16,3))
    z('21c', (8/Rational(16,3)-1)*100, 50)
elif einheit == 'e3':
    z('23a', I(x**2,0,2)+4, Rational(20,3)); z('23b', I(4-x**2,-2,2)+4, Rational(44,3))
    z('23c', I(4-x**2/4,-4,4)+8, Rational(88,3)); z('23d', 16-I(x**3,0,2), 12)
    z('23e-stetig', (4-x**2).subs(x,1), 3); z('23e', I(4-x**2,0,1)+6, Rational(29,3))
    z('24a', Rational(20,3)*25, Rational(500,3)); z('24b', Rational(44,3)*6, 88); z('24c', 88*2.4, 211.2)
    z('24d', 110/Rational(44,3), 7.5); z('24e', I(4-x**2,-2,2)+pi*2, Rational(32,3)+2*pi)
    z('24f-nst', nst(3-x**2/3), [-3,3]); z('24f', 25*(I(3-x**2/3,-3,3)-6), 150)
    z('25a-int', I(2-x**2/2,-2,2), Rational(16,3)); z('25a-A', Rational(16,3)*9, 48); z('25a-V', 48*60, 2880)
    z('25b', 1.5/0.2, 7.5)
    z('28a-int', I(4-x**2,-1,2), 9); z('28a-dreieck', Rational(1,2)*3*3, 4.5); z('28c', (1-4.5/9)*100, 50)
    z('27a', nst(5-x**2/5), [-5,5]); z('27b', I(5-x**2/5,-5,5), Rational(100,3)); z('27c-V', Rational(100,3)*150, 5000)
    z('27c-m', 5000*2.5, 12500); z('27d', nst(5-x**2/5-4), [-sqrt(5), sqrt(5)]); z('27d-b', 2*sqrt(5), 4.4721359549995796)
elif einheit == 'e4':
    u, k, a, m, c, d, b = symbols('u k a m c d b', positive=True)
    z('30a', solve(I(2*x,0,u)-16, u), [4]); z('30b', solve(I(3*x**2,0,u)-64, u), [4])
    z('30c', solve(I(1/x**2,1,u)-Rational(3,4), u), [4]); z('30d', solve(I(x+k,0,2)-8, k), [3])
    z('30e', solve(I(4-a*x**2,-2/sqrt(a),2/sqrt(a))-Rational(32,3), a), [1])
    z('30f', solve(I(m*x-x**2,0,m)-Rational(9,2), m), [3])
    z('31a', I(x**2,0,2), Rational(8,3)); z('31b', solve(2*c-Rational(8,3), c), [Rational(4,3)]); z('31c', solve(2*m-Rational(8,3), m), [Rational(4,3)])
    z('32b-rechts', I(4-x**2,0,2), Rational(16,3)); z('32b-kontrolle', float(nsolve(4*u-u**3/3-Rational(8,3), u, 0.7)), 0.6946)
    z('32c-kontrolle', float(nsolve(I(4-x**2-k,-sqrt(4-k),sqrt(4-k))-Rational(16,3), k, 1.5)), 1.4802)
    z('32d-ges', I(x**2/4,0,4), Rational(16,3)); z('32d', solve(2*b-Rational(8,3), b), [Rational(4,3)])
    z('32e', solve(I(x**3-3*x**2+d,0,3), d), [Rational(9,4)])
    z('33a-ges', I(x**2,0,3), 9); z('33a', solve(u**3/3-Rational(9,2), u), [Rational(27,2)**Rational(1,3)]); z('33a-num', N(Rational(27,2)**Rational(1,3)), 2.381)
    z('33b-2', I(x**2+1,0,2), Rational(14,3)); z('33b-3', I(x**2+1,0,3), 12)
    z('34d-sym', I(x**3-4*x,-3,3), 0); z('34d', solve(I(x**3-4*x+c,-3,3)-12, c), [2])
elif einheit == 'e5':
    z('36a', I(2-x**2/8,0,4), Rational(16,3)); z('36b', I(2*sin(pi*x/3),0,3), 12/pi); z('36c', I(2*sin(pi*x/3),0,6), 0)
    z('36d', 2*12/pi, 7.639); z('36e', I(x**2/2,0,2), Rational(4,3))
    z('37a', [I(x**2-1,0,2), A(x**2-1,0,1)+A(x**2-1,1,2)], [Rational(2,3), 2])
    z('37b', [I(x**3,-1,2), A(x**3,-1,0)+A(x**3,0,2)], [Rational(15,4), Rational(17,4)])
    z('37c', [I(x**3-4*x,-2,2), A(x**3-4*x,-2,0)+A(x**3-4*x,0,2)], [0, 8])
    z('37d', [I(2*x-4,0,3), A(2*x-4,0,2)+A(2*x-4,2,3)], [-3, 5])
    z('38a', I(x**3,-3,3), 0); z('38b', I(x**5-3*x,-2,2), 0); z('38c', I(x**3+2,-2,2), 8); z('38d', I(x**7-x**3+5,-1,1), 10)
    z('38e', I((x-2)**3+1,0,4), 4); z('38f', I(sin(x),0,pi/2)/I(sin(x),0,pi), Rational(1,2))
    z('39-f', [I(x*(x-2)*(x-4)/4,0,2), I(x*(x-2)*(x-4)/4,2,4), I(x*(x-2)*(x-4)/4,0,3), I(x*(x-2)*(x-4)/4,0,5)], [1, -1, Rational(9,16), Rational(25,16)])
    z('40c', I(x**2/4+1,0,4), Rational(28,3)); z('40c-proz', (12/Rational(28,3)-1)*100, 28.571)
    z('41a-int', I(-x**2/4+3*x+15,0,12), 252); z('41a', 252/12, 21); z('41c-int', I(-x**2/4+3*x+15,3,9), 139.5); z('41c', 139.5/6, 23.25)
    z('42a-int', I(x**2-4,-3,3), -6); z('42a', A(x**2-4,-3,-2)+A(x**2-4,-2,2)+A(x**2-4,2,3), Rational(46,3))
    z('42b', 11*0.25, 2.75)
    z('44a', simplify(2*sqrt(x) - solve(Eq(x, symbols('y')**2/4), symbols('y'))[1].subs(symbols('y'), x) if False else 2*sqrt(x)-2*sqrt(x)), 0)
    z('44a-umkehr', simplify((x**2/4).subs(x, 2*sqrt(x))-x), 0); z('44a-schnitt', nst(x**2/4-2*sqrt(x)), [0,4]); z('44c', 2*I(x-x**2/4,0,4), Rational(16,3))

abw = 0
for nr, s, b in zeilen:
    if isinstance(s, list) or isinstance(b, list) or isinstance(s, str):
        ok = (s == b) if isinstance(s, str) else (len(s)==len(b) and all(abs(float(N(u))-float(N(v)))<1e-3 for u,v in zip(s,b)))
    else:
        ok = abs(float(N(s))-float(N(b))) < 1e-3
    abw += (not ok)
    print(f"{nr}: Skript {s} | Blatt {b} | {'OK' if ok else 'ABWEICHUNG'}")
print(f"Abweichungen: {abw}")
