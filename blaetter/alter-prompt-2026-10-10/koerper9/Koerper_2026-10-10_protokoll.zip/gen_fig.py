# Schrägbilder zusammengesetzter Körper (gerade Prismen mit beliebiger Vorderfläche).
# Tiefe nach rechts oben unter 45°, halbe Länge (wie die Körper der Vorlage).
# Fehlender Baustein der Vorlage: freies TikZ, im Ausgabeblock gemeldet.
import math
K = math.sqrt(0.5) / 2

def arc(cx, cy, r, a0, a1, n=36):
    return [(cx + r*math.cos(math.radians(a0+(a1-a0)*i/n)),
             cy + r*math.sin(math.radians(a0+(a1-a0)*i/n)), i in (0, n)) for i in range(n+1)]

def body(poly, depth, s, labels=(), dlab=None, extra=()):
    pts = []
    for x, y, e in poly:
        x, y = x*s, y*s
        if pts and abs(pts[-1][0]-x) < 1e-9 and abs(pts[-1][1]-y) < 1e-9:
            continue
        pts.append((x, y, e))
    if abs(pts[0][0]-pts[-1][0]) < 1e-9 and abs(pts[0][1]-pts[-1][1]) < 1e-9:
        pts.pop()
    n = len(pts); dx = dy = depth*s*K
    vis = []
    for i in range(n):
        x0, y0, _ = pts[i]; x1, y1, _ = pts[(i+1) % n]
        vis.append((y1-y0)*dx - (x1-x0)*dy > 1e-9)
    f = lambda x, y: f"({x:.3f},{y:.3f})"
    o = ["\\begin{tikzpicture}[line join=round,baseline=(current bounding box.north)]"]
    for i in range(n):
        x0, y0, _ = pts[i]; x1, y1, _ = pts[(i+1) % n]
        o.append(f"\\draw[{'thick' if vis[i] else 'dashed'}] {f(x0+dx,y0+dy)} -- {f(x1+dx,y1+dy)};")
    for i in range(n):
        x, y, e = pts[i]
        a, b = vis[i-1], vis[i]
        if a != b:
            o.append(f"\\draw[thick] {f(x,y)} -- {f(x+dx,y+dy)};")
        elif e:
            o.append(f"\\draw[{'thick' if a else 'dashed'}] {f(x,y)} -- {f(x+dx,y+dy)};")
    o.append("\\draw[thick] " + " -- ".join(f(x, y) for x, y, _ in pts) + " -- cycle;")
    for x0, y0, x1, y1, lab, pos in extra:
        o.append(f"\\draw[dashed] {f(x0*s,y0*s)} -- {f(x1*s,y1*s)} node[midway,{pos}] {{\\small {lab}}};")
    for x, y, lab, pos in labels:
        o.append(f"\\node[{pos}] at {f(x*s,y*s)} {{\\small {lab}}};")
    if dlab:
        i, lab = dlab[0], dlab[1]
        pos = dlab[2] if len(dlab) > 2 else 'below right'
        o.append(f"\\node[{pos}] at {f(pts[i][0]+dx/2,pts[i][1]+dy/2)} {{\\small {lab}}};")
    o.append("\\end{tikzpicture}")
    return "\n".join(o)

def Lp(a, b, c, d):          # unten a breit, b hoch; oben links c breit, Gesamthöhe d
    return [(0,0,1),(a,0,1),(a,b,1),(c,b,1),(c,d,1),(0,d,1)]
def hausp(w, wh, dh):        # Breite, Wandhöhe, Dachhöhe
    return [(0,0,1),(w,0,1),(w,wh,1),(w/2,wh+dh,1),(0,wh,1)]
def hallep(w, wh):           # Breite, Wandhöhe, Halbzylinder r = w/2
    return [(0,0,1),(w,0,1)] + arc(w/2, wh, w/2, 0, 180) + [(0,wh,1)]
def trogp(w, h, d):          # Block w x h, oben Rinne mit Durchmesser d
    return [(0,0,1),(w,0,1),(w,h,1)] + arc(w/2, h, d/2, 0, -180) + [(0,h,1)]
def Up(w, h, nw, nd):        # Block w x h, oben mittig Kerbe nw breit, nd tief
    m = (w-nw)/2
    return [(0,0,1),(w,0,1),(w,h,1),(w-m,h,1),(w-m,h-nd,1),(m,h-nd,1),(m,h,1),(0,h,1)]

F = {}
# Nr. 13 Vorstufe, ohne Maße
F['v_L'] = body(Lp(8,2,4,4), 3, 0.32)
F['v_haus'] = body(hausp(8,3,3), 10, 0.25)
F['v_halle'] = body(hallep(8,4), 12, 0.22)
F['v_trog'] = body(trogp(20,15,10), 40, 0.09)
# Nr. 14
F['f14e'] = body(hausp(8,3,3), 10, 0.3, [(4,0,'8 m','below'),(0,1.5,'3 m','left')], (1,'10 m'),
                 [(4,3,4,6,'3 m','right')])
F['f14f'] = body(hallep(8,4), 12, 0.28, [(4,0,'8 m','below'),(0,2,'4 m','left')], (1,'12 m'))
# Nr. 15, 16 (Buchstaben)
F['f15b'] = body(hausp(8,3,3), 10, 0.3, [(4,0,'$b$','below'),(0,1.5,'$w$','left')], (1,'$t$'),
                 [(4,3,4,6,'$k$','right')])
F['f16'] = body(hallep(8,4), 12, 0.28, [(4,0,'$b$','below'),(0,2,'$w$','left')], (1,'$t$'))
# Nr. 17
F['f17c'] = body(trogp(20,15,10), 40, 0.12, [(10,0,'20 cm','below'),(0,7.5,'15 cm','left')],
                 (1,'40 cm'), [(5,15,15,15,'','above')])
F['f17c'] = F['f17c'].replace('\\end{tikzpicture}', '\\node[left] at (-0.1,2.2) {\\small Rinne: $d = 10$ cm};\n\\end{tikzpicture}')
# Nr. 18
F['f18b'] = body(Lp(8,2,4,4), 3, 0.42, [(4,0,'8 cm','below'),(0,2,'4 cm','left'),(2,4,'4 cm','above'),
                 (8,1.45,'2 cm','left')], (5,'3 cm','above left'))
# Nr. 24
F['f24a'] = body(Up(9,4,3,2), 5, 0.38, [(4.5,0,'9 cm','below'),(0,2,'4 cm','left'),
                 (4.5,2,'3 cm','below'),(3,3,'2 cm','left')], (1,'5 cm'))
F['f18c'] = body(hausp(6,2.5,4), 9, 0.3, [(3,0,'6 m','below'),(0,1.25,'2,5 m','left')], (1,'9 m'),
                 [(3,2.5,3,6.5,'4 m','right')])
F['f22b'] = body(hausp(6,2.5,3), 9, 0.3, [(3,0,'6 m','below'),(0,1.25,'$x$','left')], (1,'9 m'),
                 [(3,2.5,3,5.5,'3 m','right')])
F['f22c'] = body(hallep(4,3), 10, 0.42, [(2,0,'4 m','below'),(0,1.5,'3 m','left')], (1,'$t$'))
F['fbeet'] = body([(0,0,1),(0.8,0,1),(0.8,0.9,1),(0,0.6,1)], 2, 2.6, [(0.4,0,'0,8 m','below'),(0,0.3,'0,6 m','left'),(0.8,0.45,'0,9 m','right')], (1,'2 m'))
F['f27'] = body([(0,0,1),(5,0,1),(5,0.5,1),(3,0.5,1)], 1.5, 1.3, [(2.5,0,'5 m','below'),(4,0.5,'2 m','above'),(5,0.25,'0,5 m','left')], (0,'1,5 m','above left'))
F['f21'] = body([(0,0,1),(6,0,1),(0,4,1)], 20, 0.3, [(3,0,'6 cm','below'),(0,2,'4 cm','left')], (1,'20 cm'))
F['pool'] = ("\\begin{tikzpicture}[scale=0.4]\n\\draw[thick] (0,0) -- (8,0) arc (-90:90:2) -- (0,4) -- cycle;\n"
             "\\draw[dashed] (8,0) -- (8,4);\n\\node[below] at (4,0) {\\small 8 m};\n\\node[left] at (0,2) {\\small 4 m};\n"
             "\\node[above] at (4,4) {\\small Draufsicht};\n\\end{tikzpicture}")
for k, v in F.items():
    open(f"fig_{k}.tex", "w").write(v + "\n")
print("Figuren:", len(F))
